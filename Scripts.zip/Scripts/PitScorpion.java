import javax.swing.JOptionPane;

public class PitScorpion extends Script {

 private int cs;
 int fightMode;
 int food ;
 int eatAtHp = 40;
 int nfoods;
 int nbanks;
 private int startxp;
 private long time;
 private boolean init;

 public PitScorpion(Extension ex) {
   super(ex);
 }

 public void init(String params) {
      Object[] option1 = {"Lobster", "Swordfish", "Shark"};
      String foodType = (String)JOptionPane.showInputDialog(null, "Food type?", "Pit Scorpion", JOptionPane.PLAIN_MESSAGE, null, option1, option1[0]);
      Object[] option2 = {"Attack", "Strength", "Defense", "Controlled"};
      String fightM = (String)JOptionPane.showInputDialog(null, "Fightmode?", "Pit Scorpion", JOptionPane.PLAIN_MESSAGE, null, option2, option2[0]);

      if(foodType.equals("Lobster")) {
          food = 373;
      } else
      if(foodType.equals("Swordfish")) {
          food = 370;
      } else
      if(foodType.equals("Shark")) {
          food = 546;
      }
     
      if(fightM.equals("Controlled")) {
          fightMode = 0;
      } else
      if(fightM.equals("Strength")) {
          fightMode = 1;
      } else
      if(fightM.equals("Attack")) {
          fightMode = 2;
      } else
      if(fightM.equals("Defense")) {
          fightMode = 3;
      }
 }

 public int main() {

   if(getFightMode() != fightMode) {
   setFightMode(fightMode);
   }

   if (!init) {
   switch (cs) {
   case 0:
   startxp = (getXpForLevel(0) + getXpForLevel(1) + getXpForLevel(2));
   break;
   }
   time = System.currentTimeMillis();
   init = true;
   }

   if(getWallObjectIdFromCoords(514, 2424) == 2) {
   atWallObject(514, 2424);
   writeLine("Opening door...");
   return random(1200, 1500);
   }

   if(getFatigue() > 90) {
   useSleepingBag();
   return 1000;
   }

   if(hasInventoryItem(food) && getCurrentLevel(3) <= eatAtHp && !inCombat()) {
   useItem(getInventoryIndex(food));
   nfoods += 1;
   return random(1100, 1500);
   }

   if(hasInventoryItem(food) && getY() > 3300) {
       int[] npc;
       npc = getNpcById(786);
       if(npc[0] != -1 && !inCombat() && !isWalking()) {
       attackNpc(npc[0]);
       return random(600, 600) + 150;
       }
   }

   if(hasInventoryItem(food) && getY() < 3300) {
       int[] stairsDown = getObjectById(new int[]{42});
       if(isAtApproxCoords(516, 2426, 10)) {
       atObject(stairsDown[1], stairsDown[2]);
       return random(800, 1000);
       }

       if(isAtApproxCoords(508, 1478, 10)) {
       atObject(stairsDown[1], stairsDown[2]);
       return random(800, 1000);
       }

       if(isAtApproxCoords(508, 538, 10)) {
       atObject(stairsDown[1], stairsDown[2]);
       return random(800, 1000);
       }
   }    

   if(getInventoryCount(food) == 0) {
       int[] stairsUp = getObjectById(new int[]{41});
       if(getY() > 3300 && getY() < 3400) {
       if(!isAtApproxCoords(518, 3370, 0)) {
       walkTo(518, 3370);
       return random(800, 1000);
       }
       if(isAtApproxCoords(518, 3370, 0)) {
       atObject(stairsUp[1], stairsUp[2]);
       return random(800, 1000);
       }
       }

       if(getY() > 500 && getY() < 550) {
       if(isAtApproxCoords(514, 538, 10)) {
       atObject(stairsUp[1], stairsUp[2]);
       return random(800, 1000);
       }
       }

       if(getY() > 1400 && getY() < 1500) {
       if(isAtApproxCoords(508, 1478, 10)) {
       atObject(stairsUp[1], stairsUp[2]);
       return random(800, 1000);
       }
       }

       if(getY() > 2400 && getY() < 2500) {
       if(isAtApproxCoords(516, 2426, 10)) {
           if(isQuestMenu()) {
           answer(0);
           return random(2200, 3000);
           }
           if(!isBanking()) {
               int banker[] = getNpcByIdNotTalk(95);
               if(banker[0] != -1) {
               talkToNpc(banker[0]);
               return 2000;
               }
               } else
               if(isBanking()) {
                   if(getInventoryCount(food) < 15) {
                   withdraw(food, getEmptySlots());
                   closeBank();
                   nbanks += 1;
                   return 1000;
               }
           }
       }
   }    
   return 1000;
 }
   return random(500, 800);
 }

 public void paint() {
   int y = 215;
   int x = 10;
   drawString("Ate: " + ""+nfoods+"" + " food", x, y, 1, 0xde623a);
   y += 15;
   drawString("Banked: " + ""+nbanks+"" + " time(s)", x, y, 1, 0xde623a);
   y += 15;
   drawString("Non HP XP Gained: " + getXPGained() + " experience", x, y, 1, 0xde623a);
   y += 15;
      drawString("Non HP XP / H: " + getXpH(), x, y, 1, 0xE01E1B);
   y += 15;
      drawString("Running for: " + getTimeRunning(), x, y, 1, 0xF21DCB);
 }

  private int getXPGained() {
      int i = 0;
      switch (cs) {
          case 0:
              i = (getXpForLevel(0) + getXpForLevel(1) + getXpForLevel(2));
              break;
      }
      return (i - startxp);
  }

  private String getTimeRunning() {
      long l = ((System.currentTimeMillis() - time) / 1000);
      if (l >= 7200) {
          return new String((l / 3600) + " hour(s), " + ((l % 3600) / 60) + " minute(s), " + (l % 60) + " second(s).");
      }
      if (l >= 3600 && l < 7200) {
          return new String((l / 3600) + " hour(s), " + ((l % 3600) / 60) + " minute(s), " + (l % 60) + " second(s).");
      }
      if (l >= 60) {
          return new String(l / 60 + " minute(s), " + (l % 60) + " second(s).");
      }
      return new String(l + " second(s).");
  }

  private long getXpH() {
      try {
   long xph = (((getXPGained()) * 60) * 60) / (((System.currentTimeMillis() - time) / 1000));
   return xph;
      } catch(ArithmeticException e) {}
      return 0;
  }
}